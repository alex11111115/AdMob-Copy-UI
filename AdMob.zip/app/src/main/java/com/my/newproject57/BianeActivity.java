package com.my.newproject57;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import androidx.cardview.widget.CardView;
import android.widget.TextView;
import android.widget.Button;
import android.view.View;
import com.bumptech.glide.Glide;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;

public class BianeActivity extends AppCompatActivity {
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear25;
	private LinearLayout linear6;
	private LinearLayout linear22;
	private LinearLayout linear23;
	private LinearLayout linear24;
	private ImageView imageview1;
	private LinearLayout linear20;
	private LinearLayout linear19;
	private CardView cardview3;
	private ImageView imageview5;
	private ImageView imageview4;
	private TextView textview7;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private LinearLayout linear14;
	private TextView textview1;
	private ImageView imageview2;
	private TextView textview2;
	private LinearLayout linear15;
	private LinearLayout linear16;
	private TextView textview3;
	private ImageView imageview3;
	private TextView textview4;
	private LinearLayout linear18;
	private LinearLayout linear17;
	private TextView textview5;
	private TextView textview6;
	private CardView cardview1;
	private CardView cardview2;
	private Button button1;
	private Button button2;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.biane);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		linear25 = findViewById(R.id.linear25);
		linear6 = findViewById(R.id.linear6);
		linear22 = findViewById(R.id.linear22);
		linear23 = findViewById(R.id.linear23);
		linear24 = findViewById(R.id.linear24);
		imageview1 = findViewById(R.id.imageview1);
		linear20 = findViewById(R.id.linear20);
		linear19 = findViewById(R.id.linear19);
		cardview3 = findViewById(R.id.cardview3);
		imageview5 = findViewById(R.id.imageview5);
		imageview4 = findViewById(R.id.imageview4);
		textview7 = findViewById(R.id.textview7);
		linear7 = findViewById(R.id.linear7);
		linear8 = findViewById(R.id.linear8);
		linear9 = findViewById(R.id.linear9);
		linear10 = findViewById(R.id.linear10);
		linear11 = findViewById(R.id.linear11);
		linear12 = findViewById(R.id.linear12);
		linear14 = findViewById(R.id.linear14);
		textview1 = findViewById(R.id.textview1);
		imageview2 = findViewById(R.id.imageview2);
		textview2 = findViewById(R.id.textview2);
		linear15 = findViewById(R.id.linear15);
		linear16 = findViewById(R.id.linear16);
		textview3 = findViewById(R.id.textview3);
		imageview3 = findViewById(R.id.imageview3);
		textview4 = findViewById(R.id.textview4);
		linear18 = findViewById(R.id.linear18);
		linear17 = findViewById(R.id.linear17);
		textview5 = findViewById(R.id.textview5);
		textview6 = findViewById(R.id.textview6);
		cardview1 = findViewById(R.id.cardview1);
		cardview2 = findViewById(R.id.cardview2);
		button1 = findViewById(R.id.button1);
		button2 = findViewById(R.id.button2);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				/*لتعريف البوتوم شيت*/
				final com.google.android.material.bottomsheet.BottomSheetDialog bottomSheetDialog = new com.google.android.material.bottomsheet.BottomSheetDialog(BianeActivity.this);
				
				View bottomSheetView; bottomSheetView = getLayoutInflater().inflate(R.layout.install,null );
				bottomSheetDialog.setContentView(bottomSheetView);
				
				bottomSheetDialog.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
				/*لتعريف اي شئ مثل نص او لينير*/
				LinearLayout bg = (LinearLayout) bottomSheetView.findViewById(R.id.bg);
				/*لتعريف اي شئ مثل نص او لينير*/
				Button button1 = (Button) bottomSheetView.findViewById(R.id.button1);
				/*لتعريف اي شئ مثل نص او لينير*/
				ImageView imageview5 = (ImageView) bottomSheetView.findViewById(R.id.imageview5);
				/*لتعريف اي شئ مثل نص او لينير*/
				ImageView imageview1 = (ImageView) bottomSheetView.findViewById(R.id.imageview1);
				Glide.with(getApplicationContext()).load(Uri.parse("https://firebasestorage.googleapis.com/v0/b/arabs-store1.appspot.com/o/icon%2Fapp_icon.png?alt=media&token=230fc6e7-1f7b-45dc-bbff-fa2c5ba4a260")).into(imageview5);
				/*اذا يستطيع الخروج من البوتوم شيت او لا*/
				bottomSheetDialog.setCancelable(true);
				/*عند الضغط يحدث حدث*/
				imageview5.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						/*اخفاء*/
						bottomSheetDialog.dismiss();
					}
				});
				/*عند الضغط يحدث حدث*/
				button1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						SketchwareUtil.showMessage(getApplicationContext(), "يعمل 🙂");
						/*اخفاء*/
						bottomSheetDialog.dismiss();
					}
				});
				/*اظهار*/
				bottomSheetDialog.show();
			}
		});
	}
	
	private void initializeLogic() {
		Glide.with(getApplicationContext()).load(Uri.parse("https://firebasestorage.googleapis.com/v0/b/arabs-store1.appspot.com/o/icon%2Fapp_icon.png?alt=media&token=230fc6e7-1f7b-45dc-bbff-fa2c5ba4a260")).into(imageview5);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}