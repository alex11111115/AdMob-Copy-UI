package com.my.newproject57;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import androidx.cardview.widget.CardView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Button;
import java.util.Timer;
import java.util.TimerTask;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import com.bumptech.glide.Glide;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;

public class AdsRewActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private String s = "";
	private double n = 0;
	
	private LinearLayout main;
	private RelativeLayout vid1;
	private LinearLayout vid2;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private MediaController linear9;
	private CardView cardview2;
	private CardView cardview1;
	private ImageView imageview1;
	private LinearLayout linear10;
	private TextView textview1;
	private LinearLayout linear5;
	private CardView cardview4;
	private CardView cardview3;
	private LinearLayout linear6;
	private ImageView imageview2;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private TextView textview2;
	private TextView textview3;
	private ImageView imageview3;
	private ImageView imageview4;
	private Button button1;
	private ImageView imageview6;
	private LinearLayout lin;
	private ImageView imageview5;
	private LinearLayout linear11;
	private LinearLayout linear15;
	private ImageView imageview9;
	private CardView cardview7;
	private ImageView imageview8;
	private LinearLayout linear26;
	private LinearLayout linear25;
	private LinearLayout linear14;
	private CardView cardview6;
	private CardView cardview5;
	private ImageView imageview7;
	private LinearLayout linear12;
	private TextView textview4;
	private LinearLayout linear13;
	private TextView textview5;
	private TextView textview6;
	private LinearLayout linear16;
	private CardView cardview8;
	private LinearLayout linear17;
	private LinearLayout linear18;
	private LinearLayout linear19;
	private LinearLayout linear20;
	private LinearLayout linear21;
	private TextView textview7;
	private ImageView imageview10;
	private TextView textview8;
	private ImageView imageview11;
	private LinearLayout linear22;
	private LinearLayout linear23;
	private TextView textview10;
	private ImageView imageview12;
	private TextView textview9;
	private Button button2;
	
	private TimerTask t;
	private AlertDialog.Builder d;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.ads_rew);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		main = findViewById(R.id.main);
		vid1 = findViewById(R.id.vid1);
		vid2 = findViewById(R.id.vid2);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear9 = findViewById(R.id.linear9);
		cardview2 = findViewById(R.id.cardview2);
		cardview1 = findViewById(R.id.cardview1);
		imageview1 = findViewById(R.id.imageview1);
		linear10 = findViewById(R.id.linear10);
		textview1 = findViewById(R.id.textview1);
		linear5 = findViewById(R.id.linear5);
		cardview4 = findViewById(R.id.cardview4);
		cardview3 = findViewById(R.id.cardview3);
		linear6 = findViewById(R.id.linear6);
		imageview2 = findViewById(R.id.imageview2);
		linear7 = findViewById(R.id.linear7);
		linear8 = findViewById(R.id.linear8);
		textview2 = findViewById(R.id.textview2);
		textview3 = findViewById(R.id.textview3);
		imageview3 = findViewById(R.id.imageview3);
		imageview4 = findViewById(R.id.imageview4);
		button1 = findViewById(R.id.button1);
		imageview6 = findViewById(R.id.imageview6);
		lin = findViewById(R.id.lin);
		imageview5 = findViewById(R.id.imageview5);
		linear11 = findViewById(R.id.linear11);
		linear15 = findViewById(R.id.linear15);
		imageview9 = findViewById(R.id.imageview9);
		cardview7 = findViewById(R.id.cardview7);
		imageview8 = findViewById(R.id.imageview8);
		linear26 = findViewById(R.id.linear26);
		linear25 = findViewById(R.id.linear25);
		linear14 = findViewById(R.id.linear14);
		cardview6 = findViewById(R.id.cardview6);
		cardview5 = findViewById(R.id.cardview5);
		imageview7 = findViewById(R.id.imageview7);
		linear12 = findViewById(R.id.linear12);
		textview4 = findViewById(R.id.textview4);
		linear13 = findViewById(R.id.linear13);
		textview5 = findViewById(R.id.textview5);
		textview6 = findViewById(R.id.textview6);
		linear16 = findViewById(R.id.linear16);
		cardview8 = findViewById(R.id.cardview8);
		linear17 = findViewById(R.id.linear17);
		linear18 = findViewById(R.id.linear18);
		linear19 = findViewById(R.id.linear19);
		linear20 = findViewById(R.id.linear20);
		linear21 = findViewById(R.id.linear21);
		textview7 = findViewById(R.id.textview7);
		imageview10 = findViewById(R.id.imageview10);
		textview8 = findViewById(R.id.textview8);
		imageview11 = findViewById(R.id.imageview11);
		linear22 = findViewById(R.id.linear22);
		linear23 = findViewById(R.id.linear23);
		textview10 = findViewById(R.id.textview10);
		imageview12 = findViewById(R.id.imageview12);
		textview9 = findViewById(R.id.textview9);
		button2 = findViewById(R.id.button2);
		d = new AlertDialog.Builder(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (n < 25) {
					finish();
				}
				else {
					/*ده لتعريف الكاستم ديالوج و بنائة*/
					final AlertDialog d = new AlertDialog.Builder(AdsRewActivity.this).create();
					View inflate = getLayoutInflater().inflate(R.layout.exit,null); 
					d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
					d.setView(inflate);
					/*ده لتعريف الباك جروند الي هو اللينير او اي لينير*/
					inflate.findViewById(R.id.linear1);
					final LinearLayout linear1 = (LinearLayout)
					inflate.findViewById(R.id.linear1);
					/*لتعريف النص*/
					final Button button1 = (Button) inflate.findViewById(R.id.button1);
					/*لتعريف النص*/
					final Button button2 = (Button) inflate.findViewById(R.id.button2);
					/*لتعريف النص*/
					final ImageView imageview1 = (ImageView) inflate.findViewById(R.id.imageview1);
					int[] colorsYDHXFU = { Color.parseColor("#ffffff"), Color.parseColor(4) }; android.graphics.drawable.GradientDrawable YDHXFU = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation. , colorsYDHXFU);
					YDHXFU.setCornerRadii(new float[]{(int)4,(int)4,(int)4,(int)4,(int)4,(int)4,(int)0,(int)0});
					YDHXFU.setStroke((int) "#000000", Color.parseColor(2));
					 .setElevation((float) linear1);
					 .setBackground(YDHXFU);
					imageview1.setColorFilter(0xFFF0A810);
					/*عند الضغط يحدث شئ*/
					button2.setOnClickListener(new View.OnClickListener(){
								@Override
								public void onClick(View _view){
							/*اخفاء الديالوج*/
							d.dismiss();
							finish();
						}
					});
					/*عند الضغط يحدث شئ*/
					button1.setOnClickListener(new View.OnClickListener(){
								@Override
								public void onClick(View _view){
							/*اخفاء الديالوج*/
							d.dismiss();
						}
					});
					/*اظهار الديالوج*/
					d.show();
				}
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				/*لتعريف البوتوم شيت*/
				final com.google.android.material.bottomsheet.BottomSheetDialog bottomSheetDialog = new com.google.android.material.bottomsheet.BottomSheetDialog(AdsRewActivity.this);
				
				View bottomSheetView; bottomSheetView = getLayoutInflater().inflate(R.layout.install,null );
				bottomSheetDialog.setContentView(bottomSheetView);
				
				bottomSheetDialog.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
				/*لتعريف اي شئ مثل نص او لينير*/
				LinearLayout bg = (LinearLayout) bottomSheetView.findViewById(R.id.bg);
				/*لتعريف اي شئ مثل نص او لينير*/
				Button button1 = (Button) bottomSheetView.findViewById(R.id.button1);
				/*لتعريف اي شئ مثل نص او لينير*/
				ImageView imageview5 = (ImageView) bottomSheetView.findViewById(R.id.imageview5);
				/*لتعريف اي شئ مثل نص او لينير*/
				ImageView imageview1 = (ImageView) bottomSheetView.findViewById(R.id.imageview1);
				Glide.with(getApplicationContext()).load(Uri.parse("https://firebasestorage.googleapis.com/v0/b/arabs-store1.appspot.com/o/icon%2Fapp_icon.png?alt=media&token=230fc6e7-1f7b-45dc-bbff-fa2c5ba4a260")).into(imageview1);
				/*اذا يستطيع الخروج من البوتوم شيت او لا*/
				bottomSheetDialog.setCancelable(true);
				/*عند الضغط يحدث حدث*/
				imageview5.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						/*اخفاء*/
						bottomSheetDialog.dismiss();
					}
				});
				/*عند الضغط يحدث حدث*/
				button1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						SketchwareUtil.showMessage(getApplicationContext(), "يعمل 🙂");
						/*اخفاء*/
						bottomSheetDialog.dismiss();
					}
				});
				/*اظهار*/
				bottomSheetDialog.show();
			}
		});
		
		imageview7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				/*لتعريف البوتوم شيت*/
				final com.google.android.material.bottomsheet.BottomSheetDialog bottomSheetDialog = new com.google.android.material.bottomsheet.BottomSheetDialog(AdsRewActivity.this);
				
				View bottomSheetView; bottomSheetView = getLayoutInflater().inflate(R.layout.install,null );
				bottomSheetDialog.setContentView(bottomSheetView);
				
				bottomSheetDialog.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
				/*لتعريف اي شئ مثل نص او لينير*/
				LinearLayout bg = (LinearLayout) bottomSheetView.findViewById(R.id.bg);
				/*لتعريف اي شئ مثل نص او لينير*/
				Button button1 = (Button) bottomSheetView.findViewById(R.id.button1);
				/*لتعريف اي شئ مثل نص او لينير*/
				ImageView imageview5 = (ImageView) bottomSheetView.findViewById(R.id.imageview5);
				/*لتعريف اي شئ مثل نص او لينير*/
				ImageView imageview1 = (ImageView) bottomSheetView.findViewById(R.id.imageview1);
				/*اذا يستطيع الخروج من البوتوم شيت او لا*/
				bottomSheetDialog.setCancelable(true);
				Glide.with(getApplicationContext()).load(Uri.parse("https://firebasestorage.googleapis.com/v0/b/arabs-store1.appspot.com/o/icon%2Fapp_icon.png?alt=media&token=230fc6e7-1f7b-45dc-bbff-fa2c5ba4a260")).into(imageview1);
				/*عند الضغط يحدث حدث*/
				imageview5.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						/*اخفاء*/
						bottomSheetDialog.dismiss();
					}
				});
				/*عند الضغط يحدث حدث*/
				button1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						SketchwareUtil.showMessage(getApplicationContext(), "يعمل 🙂");
						/*اخفاء*/
						bottomSheetDialog.dismiss();
					}
				});
				/*اظهار*/
				bottomSheetDialog.show();
			}
		});
	}
	
	private void initializeLogic() {
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
		vid2.setVisibility(View.GONE);
		vid1.setVisibility(View.VISIBLE);
		n = 31;
		textview1.setText(String.valueOf((long)(n)).concat(" seconds remaining"));
		Glide.with(getApplicationContext()).load(Uri.parse("https://firebasestorage.googleapis.com/v0/b/arabs-store1.appspot.com/o/icon%2Fapp_icon.png?alt=media&token=230fc6e7-1f7b-45dc-bbff-fa2c5ba4a260")).into(imageview2);
		Glide.with(getApplicationContext()).load(Uri.parse("https://firebasestorage.googleapis.com/v0/b/arabs-store1.appspot.com/o/icon%2Fapp_icon.png?alt=media&token=230fc6e7-1f7b-45dc-bbff-fa2c5ba4a260")).into(imageview9);
		imageview5.setColorFilter(0xFF3898A8);
		s = "https://www.facebook.com/105379874481483/posts/507029180983215/?sfnsn=scwspmo";
		final VideoView vd = new VideoView(AdsRewActivity.this);
		vd.setLayoutParams(new LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.MATCH_PARENT));
		linear4.addView(vd);
		/**/
		/*
final MediaController co = new MediaController(AdsRewActivity.this);
co.setLayoutParams(new LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.MATCH_PARENT));
vd.addView(co);
vd.setMediaController(co);
vd.setVideoURI(Uri.parse(s));
*/
		final java.io.File vdF = new java.io.File(getCacheDir(), "video.mp4");
		if (!vdF.exists()) {
			try {
				java.io.InputStream vdasset = getAssets().open("video.mp4");
				java.io.FileOutputStream vdFOS = null;
				vdFOS = new java.io.FileOutputStream(vdF);
				final byte[] vdB = new byte[1024];
				int vdS;
				while ((vdS = vdasset.read(vdB)) != -1) {
					vdFOS.write(vdB, 0, vdS);
				}
				vdasset.close();
				vdFOS.close();
			} catch (java.io.IOException e) {
			}
		}
		vd.setVideoPath(vdF.getAbsolutePath());
		vd.requestFocus();
		vd.start();
		/*
vd.setOnPreparedListener(new MediaPlayer.OnPreparedListener(){
			@Override
			public void onPrepared(MediaPlayer _mediaPlayer){
*/
		t = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (n == 0) {
							textview4.setText("Reward granted");
							overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
							textview1.setText("Reward granted");
							overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
							vid2.setVisibility(View.VISIBLE);
							overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
							vid1.setVisibility(View.GONE);
							vd.pause();
							overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
							t.cancel();
							overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
						}
						else {
							n--;
							textview1.setText(String.valueOf((long)(n)).concat(" seconds remaining"));
							if (n < 25) {
								imageview1.setImageResource(R.drawable.ic_close_black);
							}
							else {
								imageview1.setImageResource(R.drawable.ic_clear_grey);
							}
						}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(t, (int)(0), (int)(1000));
		imageview9.setZ(100);
	}
	
	@Override
	public void onStop() {
		super.onStop();
		t.cancel();
	}
	
	@Override
	public void onPause() {
		super.onPause();
		t.cancel();
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		t.cancel();
	}
	
	@Override
	public void onBackPressed() {
		if (n < 25) {
			finish();
		}
		else {
			/*ده لتعريف الكاستم ديالوج و بنائة*/
			final AlertDialog d = new AlertDialog.Builder(AdsRewActivity.this).create();
			View inflate = getLayoutInflater().inflate(R.layout.exit,null); 
			d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
			d.setView(inflate);
			/*ده لتعريف الباك جروند الي هو اللينير او اي لينير*/
			inflate.findViewById(R.id.linear1);
			final LinearLayout linear1 = (LinearLayout)
			inflate.findViewById(R.id.linear1);
			/*لتعريف النص*/
			final Button button1 = (Button) inflate.findViewById(R.id.button1);
			/*لتعريف النص*/
			final Button button2 = (Button) inflate.findViewById(R.id.button2);
			/*لتعريف النص*/
			final ImageView imageview1 = (ImageView) inflate.findViewById(R.id.imageview1);
			int[] colorsYDHXFU = { Color.parseColor("#ffffff"), Color.parseColor(4) }; android.graphics.drawable.GradientDrawable YDHXFU = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation. , colorsYDHXFU);
			YDHXFU.setCornerRadii(new float[]{(int)4,(int)4,(int)4,(int)4,(int)4,(int)4,(int)0,(int)0});
			YDHXFU.setStroke((int) "#000000", Color.parseColor(2));
			 .setElevation((float) linear1);
			 .setBackground(YDHXFU);
			imageview1.setColorFilter(0xFFF0A810);
			/*عند الضغط يحدث شئ*/
			button2.setOnClickListener(new View.OnClickListener(){
						@Override
						public void onClick(View _view){
					/*اخفاء الديالوج*/
					d.dismiss();
					finish();
				}
			});
			/*عند الضغط يحدث شئ*/
			button1.setOnClickListener(new View.OnClickListener(){
						@Override
						public void onClick(View _view){
					/*اخفاء الديالوج*/
					d.dismiss();
				}
			});
			/*اظهار الديالوج*/
			d.show();
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}