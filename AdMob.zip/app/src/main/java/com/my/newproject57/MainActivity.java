package com.my.newproject57;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	
	private Button button1;
	private Button button2;
	private Button button3;
	private LinearLayout linear1;
	private TextView textview1;
	
	private Intent i = new Intent();
	private AlertDialog.Builder open;
	private TimerTask t;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		button1 = findViewById(R.id.button1);
		button2 = findViewById(R.id.button2);
		button3 = findViewById(R.id.button3);
		linear1 = findViewById(R.id.linear1);
		textview1 = findViewById(R.id.textview1);
		open = new AlertDialog.Builder(this);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), AdsRewActivity.class);
				startActivity(i);
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), BianeActivity.class);
				startActivity(i);
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				/*لتعريف البوتوم شيت*/
				final com.google.android.material.bottomsheet.BottomSheetDialog bottomSheetDialog = new com.google.android.material.bottomsheet.BottomSheetDialog(MainActivity.this);
				
				View bottomSheetView; bottomSheetView = getLayoutInflater().inflate(R.layout.open_ad,null );
				bottomSheetDialog.setContentView(bottomSheetView);
				
				bottomSheetDialog.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
				/*لتعريف اي شئ مثل نص او لينير*/
				LinearLayout main = (LinearLayout) bottomSheetView.findViewById(R.id.main);
				/*لتعريف اي شئ مثل نص او لينير*/
				LinearLayout bg1 = (LinearLayout) bottomSheetView.findViewById(R.id.bg1);
				/*لتعريف اي شئ مثل نص او لينير*/
				LinearLayout bg2 = (LinearLayout) bottomSheetView.findViewById(R.id.bg2);
				/*لتعريف اي شئ مثل نص او لينير*/
				ImageView icon = (ImageView) bottomSheetView.findViewById(R.id.icon);
				/*لتعريف اي شئ مثل نص او لينير*/
				ImageView skip = (ImageView) bottomSheetView.findViewById(R.id.skip);
				/*لتعريف اي شئ مثل نص او لينير*/
				TextView name = (TextView) bottomSheetView.findViewById(R.id.name);
				/*لتعريف اي شئ مثل نص او لينير*/
				TextView textview1 = (TextView) bottomSheetView.findViewById(R.id.textview1);
				/*لتعريف اي شئ مثل نص او لينير*/
				ProgressBar prog = (ProgressBar) bottomSheetView.findViewById(R.id.prog);
				/*اذا يستطيع الخروج من البوتوم شيت او لا*/
				bottomSheetDialog.setCancelable(false);
				skip.setColorFilter(0xFF3880F0);
				prog.setVisibility(View.VISIBLE);
				skip.setVisibility(View.GONE);
				textview1.setText("Loading...");
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								prog.setVisibility(View.GONE);
								skip.setVisibility(View.VISIBLE);
								textview1.setText("Continue to app");
							}
						});
					}
				};
				_timer.schedule(t, (int)(3000));
				int[] colorsKDHSJ = { 0xFFFFFFFF, 0xFFFFFFFF }; android.graphics.drawable.GradientDrawable KDHSJ = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsKDHSJ);
				KDHSJ.setCornerRadii(new float[]{(int)12,(int)12,(int)0,(int)0,(int)0,(int)0,(int)12,(int)12});
				KDHSJ.setStroke((int) 0, 0xFF000000);
				bg1.setElevation((float) 4);
				bg1.setBackground(KDHSJ);
				int[] colorsKDNDN = { 0xFFFFFFFF, 0xFFFFFFFF }; android.graphics.drawable.GradientDrawable KDNDN = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsKDNDN);
				KDNDN.setCornerRadii(new float[]{(int)12,(int)12,(int)12,(int)12,(int)0,(int)0,(int)0,(int)0});
				KDNDN.setStroke((int) 0, 0xFF000000);
				bg2.setElevation((float) 4);
				bg2.setBackground(KDNDN);
				icon.setImageResource(R.drawable.app_icon);
				/*عند الضغط يحدث حدث*/
				skip.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						/*اخفاء*/
						bottomSheetDialog.dismiss();
					}
				});
				/*اظهار*/
				bottomSheetDialog.show();
			}
		});
	}
	
	private void initializeLogic() {
	}
	
	@Override
	public void onResume() {
		super.onResume();
		/*لتعريف البوتوم شيت*/
		final com.google.android.material.bottomsheet.BottomSheetDialog bottomSheetDialog = new com.google.android.material.bottomsheet.BottomSheetDialog(MainActivity.this);
		
		View bottomSheetView; bottomSheetView = getLayoutInflater().inflate(R.layout.open_ad,null );
		bottomSheetDialog.setContentView(bottomSheetView);
		
		bottomSheetDialog.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
		/*لتعريف اي شئ مثل نص او لينير*/
		LinearLayout main = (LinearLayout) bottomSheetView.findViewById(R.id.main);
		/*لتعريف اي شئ مثل نص او لينير*/
		LinearLayout bg1 = (LinearLayout) bottomSheetView.findViewById(R.id.bg1);
		/*لتعريف اي شئ مثل نص او لينير*/
		LinearLayout bg2 = (LinearLayout) bottomSheetView.findViewById(R.id.bg2);
		/*لتعريف اي شئ مثل نص او لينير*/
		ImageView icon = (ImageView) bottomSheetView.findViewById(R.id.icon);
		/*لتعريف اي شئ مثل نص او لينير*/
		ImageView skip = (ImageView) bottomSheetView.findViewById(R.id.skip);
		/*لتعريف اي شئ مثل نص او لينير*/
		TextView name = (TextView) bottomSheetView.findViewById(R.id.name);
		/*لتعريف اي شئ مثل نص او لينير*/
		TextView textview1 = (TextView) bottomSheetView.findViewById(R.id.textview1);
		/*لتعريف اي شئ مثل نص او لينير*/
		ProgressBar prog = (ProgressBar) bottomSheetView.findViewById(R.id.prog);
		/*اذا يستطيع الخروج من البوتوم شيت او لا*/
		bottomSheetDialog.setCancelable(false);
		skip.setColorFilter(0xFF3880F0);
		prog.setVisibility(View.VISIBLE);
		skip.setVisibility(View.GONE);
		textview1.setText("Loading...");
		t = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						prog.setVisibility(View.GONE);
						skip.setVisibility(View.VISIBLE);
						textview1.setText("Continue to app");
					}
				});
			}
		};
		_timer.schedule(t, (int)(3000));
		int[] colorsKDHSJ = { 0xFFFFFFFF, 0xFFFFFFFF }; android.graphics.drawable.GradientDrawable KDHSJ = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsKDHSJ);
		KDHSJ.setCornerRadii(new float[]{(int)12,(int)12,(int)0,(int)0,(int)0,(int)0,(int)12,(int)12});
		KDHSJ.setStroke((int) 0, 0xFF000000);
		bg1.setElevation((float) 4);
		bg1.setBackground(KDHSJ);
		int[] colorsKDNDN = { 0xFFFFFFFF, 0xFFFFFFFF }; android.graphics.drawable.GradientDrawable KDNDN = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsKDNDN);
		KDNDN.setCornerRadii(new float[]{(int)12,(int)12,(int)12,(int)12,(int)0,(int)0,(int)0,(int)0});
		KDNDN.setStroke((int) 0, 0xFF000000);
		bg2.setElevation((float) 4);
		bg2.setBackground(KDNDN);
		icon.setImageResource(R.drawable.app_icon);
		/*عند الضغط يحدث حدث*/
		skip.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				/*اخفاء*/
				bottomSheetDialog.dismiss();
			}
		});
		/*اظهار*/
		bottomSheetDialog.show();
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}